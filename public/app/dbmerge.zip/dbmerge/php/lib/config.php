<?php

define('API_URL', 'http://platform.fatsecret.com/js?');

//please register at http://platform.fatsecret.com for an API KEY 
define('API_KEY', 'NOT SET');

//please register at http://platform.fatsecret.com for an API SECRET
define('API_SECRET', 'NOT SET'); 

?>