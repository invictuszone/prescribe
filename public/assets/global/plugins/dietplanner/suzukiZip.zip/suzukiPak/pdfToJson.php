<?php
header('Access-Control-Allow-Origin: *'); 
include 'vendor/autoload.php';
include 'FPP.php';


//$panelName = 'IgG ELISA 184 Food Panel';		$filename = 'pdfs/184G serum 12.16 (1).pdf';
//$arr = pdfText($panelName,$filename);
//$panelName = 'IgG ELISA 184 Food Panel';		$filename = 'pdfs/IgG3.pdf';
//$panelName = 'IgA ELISA';		$filename = 'pdfs/IGA.pdf';
//$panelName = '12 IgE ImmunoCAP & ImmunoGLOBULINS Report';	$filename = 'pdfs/IGE12.pdf';

//$arr = pdfText($panelName,$filename);

//die();


function pdfText($panelName,$filename){
	$parser = new \Smalot\PdfParser\Parser();
	$pdf    = $parser->parseFile($filename);
	$text = $pdf->getText();
        $data = parseFoodPanel($panelName,$text);
	return $data ;
}

if(isset($_REQUEST['panel']))
{
	$panelName = $_REQUEST['panel'];
}

$data = array();
 $text= "";
if(isset($_GET['files']))
{	
	$error = false;
	$files = array();

	$uploaddir = './pdfs/';
	foreach($_FILES as $file)
	{
		if(move_uploaded_file($file['tmp_name'], $uploaddir .basename($file['name'])))
		{
			$files[] = $uploaddir .$file['name'];
                        $text =  pdfText($panelName,$uploaddir .$file['name']);
		}
		else
		{
		    $error = true;
		}
	}
	$data = ($error) ? array('error' => 'There was an error uploading your file') :$text;
}

echo json_encode($data);









?>