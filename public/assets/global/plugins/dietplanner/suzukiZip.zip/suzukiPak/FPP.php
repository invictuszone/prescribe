<?php

function parseFoodPanel($panelName,$text )
{
   	$data = explode(PHP_EOL,$text);
	$data = array_map(function($val) {  return explode("+++",$val); }, $data );
        
	$scoreList = array();
    $catagoryOrder = array();
	$itemCount = 0;
	
	if($panelName == 'IgG ELISA 184 Food Panel'){
		$addToList = false;
		$first = "Beef";
		$last = 'Reference Range';
        $cat = "";
		$length = count($data);
		$finalArray = [];
		for ($i = 0; $i < $length ; $i++){
			$tLen = count($data[$i]);
			for ($j = 0; $j < $tLen ; $j++) {
				$currText = trim($data[$i][$j]);
				if(trim($currText) == $first){
					$addToList = true;
				}
				if($currText == $last){
					$addToList = false;
				}
				if($addToList and $currText!="" and $currText !="*" and (strtoupper($currText) !== $currText || preg_match( '~\d~', $currText))){
					array_push($finalArray ,$currText);
				}
			}
		}			
		$length = count($finalArray);
		for ($i = 0; $i < $length ; $i=$i+3) {
			$temp = array('name' => $finalArray[$i],'score' => $finalArray[$i+1],'class' => $finalArray[$i+2]);
			$scoreList[] = $temp ; 
		}
	}
	else if($panelName == '25 IgE ImmunoCAP & ImmunoGLOBULINS Report')
	{
		$reactionList = ['0','0/I','I','II','III','IV','V','VI'];
		$addToList = false;
		$first = 'Mussel, Blue';
		$last = 'Lentil';
		$length = count($data);
		for ($i = 0; $i < $length ; $i++) {
				$name = $data[$i][0];
				if($name == $first)
					$addToList = true;
				if($addToList){
					$key = array_search($data[$i][2], $reactionList);
					$temp = array('name' => $name,'score' => $data[$i][1],'class' => $key);
					$scoreList[] = $temp ; 
				}
				if($name == $last)
					$addToList = false;
		}

	}
	
	//echo count($scoreList);

	//print "<pre>";
	//print_r($scoreList);
	//print "</pre>";

	$data = array();
	$data ['Panel Name'] = $panelName ;
	$data ['Total Foods'] = $itemCount;
	$data ['Type'] = (count($scoreList) > 1) ? 'Catagorized' : 'Non-Catagorized';
	$data ['Scores'] = $scoreList;
	$data ['catagoryOrder'] = $catagoryOrder;

	return $data ;
}

?>